# Proposals

This directory contains design documents for accepted proposals. To propose a new feature use the [template document][template]. Note that if the proposal gets accepted whoever is the proposal implementation owner is accepted to carry out the implementation, the implementation owner can be different to the proposal creator.

[template]: ./TEMPLATE.md
